﻿Imports MySql.Data.MySqlClient
Public Module modDBOperations
    Public oConn As MySqlConnection = Nothing
    Public oTransaction As MySqlTransaction = Nothing
    Structure EmployeeDetails
        Dim empid As Integer
        Dim sname As String
        Dim dtDob As Date
        Dim sgender As String
        Dim sdesignation As String
        Dim sdescription As String
        Dim desalary As Decimal
        Sub initialize()
            empid = 0
            sname = ""
            dtDob = Date.MinValue
            sgender = ""
            sdesignation = ""
            sdescription = ""
            desalary = 0.0
        End Sub
    End Structure

    Structure field_lookup
        Dim scategory As String
        Dim sdescription As String
        Dim slist As String
        Dim isort As Integer
        Sub initialize()
            scategory = ""
            sdescription = ""
            slist = ""
            isort = 0
        End Sub
    End Structure
    '*******************************************************************************
    ' MySQLConnectionOpen (FUNCTION)
    '
    ' PARAMETERS:
    ' (In) - None
    '
    ' RETURN VALUE:
    ' Boolean - Returns True if MySQL connection is opened successfully
    '                   False if failed to open MySQL connection
    '
    ' DESCRIPTION:
    '             Tries to open up the MySQL connection with connection string
    '             as Settings.m_sCONN_STRING
    ' 
    '******************************************************************************* 
    Public Function MySQLConnectionOpen() As Boolean
        Try
            oConn = New MySqlConnection
            If oConn.State = ConnectionState.Open Then
                oConn.Close()
            End If
            oConn.ConnectionString = Settings.m_sCONN_STRING
            oConn.Open()
            Return (True)
        Catch exError As MySqlException
            If Not (oConn Is Nothing) Then
                oConn.Dispose()
            End If
            Return (False)
        End Try
    End Function

    '*******************************************************************************
    ' MySQLConnectionClose (FUNCTION)
    '
    ' PARAMETERS:
    ' (In) - None
    '
    ' RETURN VALUE:
    ' Boolean - Returns True if MySQL connection is closed successfully
    '                   False if failed to close MySQL connection
    '
    ' DESCRIPTION:
    '             Closes the MySQL connection and disposes the connection object
    ' 
    '******************************************************************************* 
    Public Function MySQLConnectionClose() As Boolean
        Try
            If Not IsNothing(oConn) Then
                If oConn.State = ConnectionState.Open Then
                    oConn.Close()
                End If
                oConn.Dispose()
            End If
            Return (True)
        Catch exError As MySqlException
            Return (False)
        End Try
    End Function
    Function StartTransaction() As Boolean
        If MySQLConnectionOpen() = False Then
            Return False
        End If
        oTransaction = oConn.BeginTransaction
        Return True
    End Function
    Sub SaveTransaction(ByVal b_CommitRequired As Boolean)
        If b_CommitRequired = True Then
            oTransaction.Commit()
        Else
            oTransaction.Rollback()
        End If
        If oConn.State = ConnectionState.Open Then
            oConn.Close()
        End If
    End Sub


    '*******************************************************************************
    ' GetDBRecords (FUNCTION)
    '
    ' PARAMETERS:
    ' (In) - s_TableName -  The table name on which the SQL statement is executed
    '        s_WhereCriteria - The entire string that goes after the WHERE clause
    '        s_OrderByColumn - The Order         
    '
    ' RETURN VALUE:
    ' Boolean - Returns False if exception
    '                   True if executed successfully
    ' DESCRIPTION:
    '             The sSqlStatement (SELECT) is executed and the "oData" datatable is filled
    '             with DB records
    '             If executed successfully, returns True
    '             If exception False
    ' 
    '******************************************************************************* 
    Public Function GetDBRecords(ByVal s_TableName As String, _
    ByVal s_WhereCriteria As String, _
    ByVal s_OrderByColumn As String, _
    ByRef o_Data As DataTable, _
    Optional ByVal s_ColumnList As String = "*", _
    Optional ByVal s_GroupBy As String = "*", _
    Optional ByVal s_HavingBy As String = "*") As Boolean

        Dim sSqlStatement As String
        'Dim arrayListInfo As ArrayList
        If s_GroupBy = "*" Then
            sSqlStatement = "SELECT " + s_ColumnList + " FROM " + s_TableName + " WHERE " + s_WhereCriteria + " ORDER BY " + s_OrderByColumn
        Else
            sSqlStatement = "SELECT " + s_ColumnList + " FROM " + s_TableName + " WHERE " + s_WhereCriteria + " AND " + s_GroupBy + " ORDER BY " + s_OrderByColumn
        End If

        If s_HavingBy <> "*" Then
            sSqlStatement = "SELECT " + s_ColumnList + " FROM " + s_TableName + " WHERE " + s_WhereCriteria + " GROUP BY " + s_GroupBy + " having " + s_HavingBy + " ORDER BY " + s_OrderByColumn
        End If
        Return (RetrieveSQLRecords(sSqlStatement, o_Data))
    End Function

    '*******************************************************************************
    ' RetrieveSQLRecords (FUNCTION)
    '
    ' PARAMETERS:
    ' (In) - sSqlStatement -  The SQL statement (SELECT statement) executed to retrieve the 
    '                         records
    '
    ' RETURN VALUE:
    ' Boolean - Returns False if exception
    '                   True if executed successfully
    ' DESCRIPTION:
    '             The sSqlStatement (SELECT) is executed and the "oData" datatable is filled
    '             with DB records
    '             If executed successfully, returns True
    '             If exception False is returned
    ' 
    '******************************************************************************* 
    Private Function RetrieveSQLRecords(ByVal s_SqlStatement As String, _
    ByRef o_Data As DataTable) As Boolean

        Dim oCommand As MySqlCommand
        Dim oAdapter As New MySqlDataAdapter
        oCommand = New MySqlCommand

        Try
            o_Data.Reset()
            oCommand.Connection = oConn
            oCommand.CommandText = s_SqlStatement
            oAdapter.SelectCommand = oCommand
            oAdapter.Fill(o_Data)
            Return (True)


        Catch ex As MySqlException
            Return (False)
            Console.WriteLine("SQL Error")
        Catch ex As Exception
            Return (False)
            Console.WriteLine("Exception")

        Finally
            If Not (oCommand Is Nothing) Then
                oCommand.Dispose()
            End If
        End Try
    End Function 'RetrieveSQLRecords

    '*******************************************************************************
    ' ExecuteSQLStmt (FUNCTION)
    '
    ' PARAMETERS:
    ' (In) - sSqlStatement -  The SQL statement executed to perform INSERT, UPDATE, DELETE
    '                         operations
    '
    ' RETURN VALUE:
    ' Boolean - Returns the number of DB records changed 
    ' DESCRIPTION:
    '             The sSqlStatement (INSERT/UPDATE/DELETE) is executed and 
    '             the count of number fo records is returned.
    ' 
    '******************************************************************************* 
    Private Function ExecuteSQLStmt(ByVal s_SqlStatement As String) As Integer

        Dim iNoOFRecords As Integer = 0 'Number of DB records updated 
        Dim oCommand As MySqlCommand
        oCommand = New MySqlCommand

        Try
            oCommand.Connection = oConn
            oCommand.Transaction = oTransaction
            oCommand.CommandText = s_SqlStatement
            iNoOFRecords = oCommand.ExecuteNonQuery()
        Catch ex As MySqlException
            Console.WriteLine("SQL Error")
        Catch ex As Exception
            Console.WriteLine("Exception")
        Finally
            If Not (oCommand Is Nothing) Then
                oCommand.Dispose()
            End If
        End Try
        Return iNoOFRecords
    End Function 'ExecuteSQLStmt 
    '*******************************************************************************
    ' ExecuteSQLCommand (FUNCTION)
    '
    ' PARAMETERS:
    ' (In) - MySqlCommand -  The SQL command to perform INSERT, UPDATE, DELETE
    '                         operations
    '
    ' RETURN VALUE:
    ' Boolean - Returns the number of DB records changed 
    ' DESCRIPTION:
    '             The MySqlCommand (INSERT/UPDATE/DELETE) is executed and 
    '             the count of number fo records is returned.
    ' 
    '******************************************************************************* 
    Private Function ExecuteSQLCommand(ByVal cmd_SqlCommand As MySqlCommand) As Integer

        Dim iNoOFRecords As Integer = 0 'Number of DB records updated 

        Try

            iNoOFRecords = cmd_SqlCommand.ExecuteNonQuery
        Catch ex As MySqlException
            Console.WriteLine("SQL Error")
        Catch ex As Exception
            Console.WriteLine("Exception")
        Finally

        End Try
        Return iNoOFRecords
    End Function 'ExecuteSQLCommand

    '*******************************************************************************
    ' GetAutoInsertedID (FUNCTION)
    '
    ' PARAMETERS:
    ' (In) - s_TableName -  The table name from which the auto inserted id is returned
    '
    ' RETURN VALUE:
    ' ULong - Returns the last inserted ID
    ' DESCRIPTION:
    '             Returns the LAST_INSERT_ID() from the s_TableName
    ' 
    '******************************************************************************* 
    Private Function GetAutoInsertedID(ByVal s_TableName As String) As ULong

        Dim ulAutoInsertedID As ULong   'Auto inserted ID
        Dim oCommand As MySqlCommand

        oCommand = New MySqlCommand

        Try

            oCommand.Connection = oConn
            oCommand.CommandText = "SELECT LAST_INSERT_ID() FROM " + Settings.SCHEMA_NAME + "." + s_TableName
            ulAutoInsertedID = oCommand.ExecuteScalar()
        Catch ex As MySqlException
            MessageBox.Show(ex.ToString)
            Console.WriteLine("SQL Error")
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Console.WriteLine("Exception")
        Finally
            If Not (oCommand Is Nothing) Then
                oCommand.Dispose()
            End If
        End Try
        Return ulAutoInsertedID
    End Function 'GetAutoInsertedID    





    Public Function GetEmployeeDetails() As ArrayList
        Dim sTableName As String
        Dim sWhereCriteria As String
        Dim sOrderByColumn As String
        Dim icount As Integer
        Dim iitemcount As Integer
        Dim estructure As EmployeeDetails
        Dim arraylistemployee As New System.Collections.ArrayList()
        Dim dtble As New DataTable
        Dim bConnectionOpened As Boolean
        bConnectionOpened = False
        sTableName = "" + Settings.SCHEMA_NAME + ".employee_details E"
        sWhereCriteria = "E.Employee_Name <>''"
        sOrderByColumn = "E.Employee_id"
        If oConn Is Nothing Then
            If MySQLConnectionOpen() = False Then
                dtble.Dispose()
                Return arraylistemployee
            End If
        Else
            If oConn.State = ConnectionState.Open Then
                bConnectionOpened = True
            Else
                If MySQLConnectionOpen() = False Then
                    dtble.Dispose()
                    Return arraylistemployee
                End If
            End If
        End If
        If GetDBRecords(sTableName, sWhereCriteria, sOrderByColumn, dtble) Then
            icount = dtble.Rows.Count
            If icount > 0 Then
                For iitemcount = 0 To icount - 1
                    estructure.empid = dtble.Rows(iitemcount).Item("Employee_id")
                    estructure.sname = dtble.Rows(iitemcount).Item("Employee_Name")
                    estructure.dtDob = dtble.Rows(iitemcount).Item("DOB")
                    estructure.sgender = dtble.Rows(iitemcount).Item("Gender")
                    estructure.sdescription = dtble.Rows(iitemcount).Item("Department")
                    estructure.sdesignation = dtble.Rows(iitemcount).Item("Designation")
                    estructure.desalary = dtble.Rows(iitemcount).Item("Salary")

                    arraylistemployee.Add(estructure)
                Next iitemcount

            End If
            If bConnectionOpened = False Then
                MySQLConnectionClose()
            End If

            dtble.Dispose()
        End If
        Return arraylistemployee
    End Function



    Public Function AddtoEmployee(ByRef EmployeeRecord As EmployeeDetails) As Boolean
        Dim sInsertSQLQuery As String
        Dim cmdMySqlCommand As MySqlCommand
        Dim bRowAppended As Boolean
        Dim empID As ULong

        sInsertSQLQuery = "INSERT INTO " + Settings.SCHEMA_NAME + ".employee_details " _
          & "(Employee_Name,DOB,Gender,Department,Designation,Salary) " _
          & "VALUES" _
          & "(?Employee_Name,?DOB,?gender,?Department,?Designation,?Salary) "

        bRowAppended = False

        cmdMySqlCommand = New MySqlCommand
        cmdMySqlCommand.Connection = oConn
        cmdMySqlCommand.CommandText = sInsertSQLQuery

        cmdMySqlCommand.Parameters.AddWithValue("?Employee_Name", EmployeeRecord.sname)
        cmdMySqlCommand.Parameters.AddWithValue("?DOB", EmployeeRecord.dtDob)
        cmdMySqlCommand.Parameters.AddWithValue("?Gender", EmployeeRecord.sgender)
        cmdMySqlCommand.Parameters.AddWithValue("?Department", EmployeeRecord.sdescription)
        cmdMySqlCommand.Parameters.AddWithValue("?Designation", EmployeeRecord.sdesignation)
        cmdMySqlCommand.Parameters.AddWithValue("?Salary", EmployeeRecord.desalary)


        If ExecuteSQLCommand(cmdMySqlCommand) > 0 Then
            bRowAppended = True
            empID = GetAutoInsertedID("employee_details")
            EmployeeRecord.sname = empID
        End If

        If Not (cmdMySqlCommand Is Nothing) Then
            cmdMySqlCommand.Dispose()
        End If
        Return bRowAppended
    End Function

    Public Function updatetoEmployeeTable(ByVal emprecord As EmployeeDetails) As Boolean
        Dim sSqlStatement As String
        Dim oData As New DataTable
        Dim cmdMySqlCommand As MySqlCommand
        Dim bUpdateStatus As Boolean

        bUpdateStatus = False
        sSqlStatement = "UPDATE " + Settings.SCHEMA_NAME + ".employee_details SET " _
        & "Employee_Name=?Employee_Name, " _
        & "DOB=?DOB," _
        & "Gender=?Gender," _
        & "Department=?Department," _
        & "Designation=?Designation," _
        & "Salary=?Salary" _
        & " WHERE employee_details.Employee_id= " + """" + emprecord.empid.ToString + """"

        cmdMySqlCommand = New MySqlCommand
        cmdMySqlCommand.Connection = oConn
        cmdMySqlCommand.CommandText = sSqlStatement
        cmdMySqlCommand.CommandTimeout = 31536000
        cmdMySqlCommand.Parameters.AddWithValue("?Employee_id", emprecord.empid)
        cmdMySqlCommand.Parameters.AddWithValue("?Employee_Name", emprecord.sname)
        cmdMySqlCommand.Parameters.AddWithValue("?DOB", emprecord.dtDob)
        cmdMySqlCommand.Parameters.AddWithValue("?Gender", emprecord.sgender)
        cmdMySqlCommand.Parameters.AddWithValue("?Department", emprecord.sdescription)
        cmdMySqlCommand.Parameters.AddWithValue("?Designation", emprecord.sdesignation)

        cmdMySqlCommand.Parameters.AddWithValue("?Salary", emprecord.desalary)

        If ExecuteSQLCommand(cmdMySqlCommand) > 0 Then
            bUpdateStatus = True
        End If
        If Not (cmdMySqlCommand Is Nothing) Then
            cmdMySqlCommand.Dispose()
        End If


        Return bUpdateStatus

    End Function


    Public Function GetFieldLookupData(ByVal scategory As String) As ArrayList
        Dim sTableName As String
        Dim sWhereCriteria As String
        Dim sOrderByColumn As String
        Dim iApplicationCount As Integer
        Dim iItemCount As Integer
        Dim sColumnList As String = ""
        Dim field As field_lookup
        Dim arrList As New System.Collections.ArrayList()
        Dim oData As New DataTable
        Dim bConnectionAlreadyOpened As Boolean
        bConnectionAlreadyOpened = False
        sTableName = "" + Settings.SCHEMA_NAME + ".field_lookup A"
        sWhereCriteria = "A.category='" + scategory + "'"
        sOrderByColumn = "A.sort_Oder"

        If oConn Is Nothing Then
            If MySQLConnectionOpen() = False Then
                oData.Dispose()
                Return arrList
            End If
        Else
            If oConn.State = ConnectionState.Open Then
                bConnectionAlreadyOpened = True
            Else
                If MySQLConnectionOpen() = False Then
                    oData.Dispose()
                    Return arrList
                End If
            End If
        End If
        If MySQLConnectionOpen() Then
            If GetDBRecords(sTableName, sWhereCriteria, sOrderByColumn, oData) Then
                iApplicationCount = oData.Rows.Count
                If iApplicationCount > 0 Then
                    For iItemCount = 0 To iApplicationCount - 1
                        field.scategory = oData.Rows(iItemCount).Item("category")
                        ' If oData.Rows(iItemCount).Item("description").ToString() <> "" Then
                        field.sdescription = oData.Rows(iItemCount).Item("description")
                        'End If
                        'If oData.Rows(iItemCount).Item("list_value").ToString() <> "" Then
                        field.slist = oData.Rows(iItemCount).Item("list_value")
                        ' End If
                        arrList.Add(field)
                    Next iItemCount
                End If
            End If
            If bConnectionAlreadyOpened = False Then
                MySQLConnectionClose()
            End If
        End If
        oData.Dispose()
        Return arrList

    End Function


    Public Function GetEmployeeDetailsTable() As ArrayList
        Dim sTableName As String
        Dim sWhereCriteria As String
        Dim sOrderByColumn As String
        Dim iApplicationCount As Integer
        Dim iItemCount As Integer
        Dim oApplication As EmployeeDetails
        Dim arrlstStudentList As New System.Collections.ArrayList()
        'Contains the "Application struct" type members
        Dim oData As New DataTable
        Dim bConnectionAlreadyOpened As Boolean
        bConnectionAlreadyOpened = False
        sTableName = "" + Settings.SCHEMA_NAME + ".employee_details A"

        'sWhereCriteria = "A.Status = 'A'" _
        ' & " AND A.App_Name = " + """" + s_AppName + """"

        sWhereCriteria = "A.Employee_Name<> ''"

        sOrderByColumn = "A.Employee_id"

        If oConn Is Nothing Then
            If MySQLConnectionOpen() = False Then
                oData.Dispose()
                Return arrlstStudentList
            End If
        Else
            If oConn.State = ConnectionState.Open Then
                bConnectionAlreadyOpened = True
            Else
                If MySQLConnectionOpen() = False Then
                    oData.Dispose()
                    Return arrlstStudentList
                End If
            End If
        End If
        'If MySQLConnectionOpen() Then
        If GetDBRecords(sTableName, sWhereCriteria, sOrderByColumn, oData) Then
            iApplicationCount = oData.Rows.Count
            If iApplicationCount > 0 Then
                For iItemCount = 0 To iApplicationCount - 1
                    ' Fill the Application object
                    oApplication.empid = oData.Rows(iItemCount).Item("Employee_id")
                    oApplication.sname = oData.Rows(iItemCount).Item("Employee_Name")
                    oApplication.dtDob = oData.Rows(iItemCount).Item("DOB")
                    oApplication.sgender = oData.Rows(iItemCount).Item("Gender")
                    oApplication.sdescription = oData.Rows(iItemCount).Item("Department")
                    oApplication.sdesignation = oData.Rows(iItemCount).Item("Designation")
                    oApplication.desalary = oData.Rows(iItemCount).Item("Salary")


                    'Add the Application object to array list
                    arrlstStudentList.Add(oApplication)
                Next iItemCount
            End If
        End If
        If bConnectionAlreadyOpened = False Then
            MySQLConnectionClose()
        End If
        'End If
        oData.Dispose()
        Return arrlstStudentList

    End Function

    Public Function GetDesignationDet(ByVal slist As String) As ArrayList
        Dim sTableName As String
        Dim sWhereCriteria As String
        Dim sOrderByColumn As String
        Dim iApplicationCount As Integer
        Dim iItemCount As Integer
        Dim sColumnList As String = ""
        Dim field As field_lookup
        Dim arrList As New System.Collections.ArrayList()
        Dim oData As New DataTable
        Dim bConnectionAlreadyOpened As Boolean
        bConnectionAlreadyOpened = False
        sTableName = "" + Settings.SCHEMA_NAME + ".field_lookup A"
        sWhereCriteria = "A.list_value='" + slist + "'"
        sOrderByColumn = "A.description "
        sColumnList = "A.description"
        If oConn Is Nothing Then
            If MySQLConnectionOpen() = False Then
                oData.Dispose()
                Return arrList
            End If
        Else
            If oConn.State = ConnectionState.Open Then
                bConnectionAlreadyOpened = True
            Else
                If MySQLConnectionOpen() = False Then
                    oData.Dispose()
                    Return arrList
                End If
            End If
        End If
        If MySQLConnectionOpen() Then
            If GetDBRecords(sTableName, sWhereCriteria, sOrderByColumn, oData, sColumnList) Then
                iApplicationCount = oData.Rows.Count
                If iApplicationCount > 0 Then
                    For iItemCount = 0 To iApplicationCount - 1
                        field.sdescription = oData.Rows(iItemCount).Item("description")
                        '  field.slist = oData.Rows(iItemCount).Item("list_value")
                        arrList.Add(field)
                    Next iItemCount
                End If
            End If
            If bConnectionAlreadyOpened = False Then
                MySQLConnectionClose()
            End If
        End If
        oData.Dispose()
        Return arrList

    End Function



   









End Module