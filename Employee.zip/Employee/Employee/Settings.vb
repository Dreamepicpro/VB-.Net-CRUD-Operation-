﻿Option Strict Off
Imports System.Drawing.Printing
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.IO
Imports System.Drawing.Imaging
Imports System.DateTime
Imports System.Configuration


Public Module Settings

    Public NAMESPACE_APP As String = "CAPELLA"

    Public m_sCONN_STRING As String
    Public SCHEMA_NAME As String

    Public iError As Integer

    Public Const SE_ERR_FNF = 2&

    ' Get and Set methods for connectionString
    Public WriteOnly Property Connection_String() As String
        Set(ByVal value As String)
            m_sCONN_STRING = value
        End Set
    End Property

    Public Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Integer, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Integer) As Integer

    Public ReadOnly Property Get_Connection_String() As String
        Get
            Return m_sCONN_STRING
        End Get
    End Property
    Public Function ProjectInitialize()

        m_sCONN_STRING = System.Configuration.ConfigurationManager.AppSettings.Get("database_server")
        SCHEMA_NAME = System.Configuration.ConfigurationManager.AppSettings.Get("schema_name")

    End Function

End Module
