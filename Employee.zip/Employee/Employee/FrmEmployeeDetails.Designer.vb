﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEmployeeDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblEmpId = New System.Windows.Forms.Label()
        Me.lblEmpName = New System.Windows.Forms.Label()
        Me.lblDob = New System.Windows.Forms.Label()
        Me.lblGender = New System.Windows.Forms.Label()
        Me.lblDepartment = New System.Windows.Forms.Label()
        Me.lblDesignation = New System.Windows.Forms.Label()
        Me.lblSalary = New System.Windows.Forms.Label()
        Me.EmpID = New System.Windows.Forms.TextBox()
        Me.Empname = New System.Windows.Forms.TextBox()
        Me.DOB = New System.Windows.Forms.MaskedTextBox()
        Me.cbxMale = New System.Windows.Forms.CheckBox()
        Me.CmbDepartment = New System.Windows.Forms.ComboBox()
        Me.cmbDesignation = New System.Windows.Forms.ComboBox()
        Me.mSalary = New System.Windows.Forms.MaskedTextBox()
        Me.cbxFemale = New System.Windows.Forms.CheckBox()
        Me.cbxTrans = New System.Windows.Forms.CheckBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.Employee_Details = New System.Windows.Forms.ListView()
        Me.clmId = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.clmName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.clmDob = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.clmGender = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.clmDepartment = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.clmDesignation = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.clmSalary = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.DataGridView = New System.Windows.Forms.DataGridView()
        Me.cmb1 = New System.Windows.Forms.ComboBox()
        Me.dtp1 = New System.Windows.Forms.DateTimePicker()
        CType(Me.DataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblEmpId
        '
        Me.lblEmpId.AutoSize = True
        Me.lblEmpId.Location = New System.Drawing.Point(203, 37)
        Me.lblEmpId.Name = "lblEmpId"
        Me.lblEmpId.Size = New System.Drawing.Size(42, 13)
        Me.lblEmpId.TabIndex = 0
        Me.lblEmpId.Text = "Emp ID"
        '
        'lblEmpName
        '
        Me.lblEmpName.AutoSize = True
        Me.lblEmpName.Location = New System.Drawing.Point(203, 113)
        Me.lblEmpName.Name = "lblEmpName"
        Me.lblEmpName.Size = New System.Drawing.Size(59, 13)
        Me.lblEmpName.TabIndex = 1
        Me.lblEmpName.Text = "Emp Name"
        '
        'lblDob
        '
        Me.lblDob.AutoSize = True
        Me.lblDob.Location = New System.Drawing.Point(203, 167)
        Me.lblDob.Name = "lblDob"
        Me.lblDob.Size = New System.Drawing.Size(30, 13)
        Me.lblDob.TabIndex = 2
        Me.lblDob.Text = "DOB"
        '
        'lblGender
        '
        Me.lblGender.AutoSize = True
        Me.lblGender.Location = New System.Drawing.Point(203, 223)
        Me.lblGender.Name = "lblGender"
        Me.lblGender.Size = New System.Drawing.Size(42, 13)
        Me.lblGender.TabIndex = 3
        Me.lblGender.Text = "Gender"
        '
        'lblDepartment
        '
        Me.lblDepartment.AutoSize = True
        Me.lblDepartment.Location = New System.Drawing.Point(451, 32)
        Me.lblDepartment.Name = "lblDepartment"
        Me.lblDepartment.Size = New System.Drawing.Size(62, 13)
        Me.lblDepartment.TabIndex = 4
        Me.lblDepartment.Text = "Department"
        '
        'lblDesignation
        '
        Me.lblDesignation.AutoSize = True
        Me.lblDesignation.Location = New System.Drawing.Point(451, 95)
        Me.lblDesignation.Name = "lblDesignation"
        Me.lblDesignation.Size = New System.Drawing.Size(63, 13)
        Me.lblDesignation.TabIndex = 5
        Me.lblDesignation.Text = "Designation"
        '
        'lblSalary
        '
        Me.lblSalary.AutoSize = True
        Me.lblSalary.Location = New System.Drawing.Point(451, 171)
        Me.lblSalary.Name = "lblSalary"
        Me.lblSalary.Size = New System.Drawing.Size(36, 13)
        Me.lblSalary.TabIndex = 6
        Me.lblSalary.Text = "Salary"
        '
        'EmpID
        '
        Me.EmpID.Location = New System.Drawing.Point(279, 35)
        Me.EmpID.Name = "EmpID"
        Me.EmpID.ReadOnly = True
        Me.EmpID.Size = New System.Drawing.Size(100, 20)
        Me.EmpID.TabIndex = 7
        '
        'Empname
        '
        Me.Empname.Location = New System.Drawing.Point(279, 109)
        Me.Empname.Name = "Empname"
        Me.Empname.Size = New System.Drawing.Size(100, 20)
        Me.Empname.TabIndex = 8
        '
        'DOB
        '
        Me.DOB.Location = New System.Drawing.Point(279, 167)
        Me.DOB.Mask = "00/00/0000"
        Me.DOB.Name = "DOB"
        Me.DOB.Size = New System.Drawing.Size(100, 20)
        Me.DOB.TabIndex = 9
        Me.DOB.ValidatingType = GetType(Date)
        '
        'cbxMale
        '
        Me.cbxMale.AutoSize = True
        Me.cbxMale.Checked = True
        Me.cbxMale.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbxMale.Location = New System.Drawing.Point(279, 219)
        Me.cbxMale.Name = "cbxMale"
        Me.cbxMale.Size = New System.Drawing.Size(49, 17)
        Me.cbxMale.TabIndex = 10
        Me.cbxMale.Text = "Male"
        Me.cbxMale.UseVisualStyleBackColor = True
        '
        'CmbDepartment
        '
        Me.CmbDepartment.FormattingEnabled = True
        Me.CmbDepartment.Location = New System.Drawing.Point(541, 32)
        Me.CmbDepartment.Name = "CmbDepartment"
        Me.CmbDepartment.Size = New System.Drawing.Size(128, 21)
        Me.CmbDepartment.TabIndex = 11
        '
        'cmbDesignation
        '
        Me.cmbDesignation.FormattingEnabled = True
        Me.cmbDesignation.Location = New System.Drawing.Point(541, 89)
        Me.cmbDesignation.Name = "cmbDesignation"
        Me.cmbDesignation.Size = New System.Drawing.Size(128, 21)
        Me.cmbDesignation.TabIndex = 1
        '
        'mSalary
        '
        Me.mSalary.Location = New System.Drawing.Point(544, 167)
        Me.mSalary.Mask = "0000000.00"
        Me.mSalary.Name = "mSalary"
        Me.mSalary.Size = New System.Drawing.Size(100, 20)
        Me.mSalary.TabIndex = 13
        '
        'cbxFemale
        '
        Me.cbxFemale.AutoSize = True
        Me.cbxFemale.Location = New System.Drawing.Point(334, 219)
        Me.cbxFemale.Name = "cbxFemale"
        Me.cbxFemale.Size = New System.Drawing.Size(60, 17)
        Me.cbxFemale.TabIndex = 14
        Me.cbxFemale.Text = "Female"
        Me.cbxFemale.UseVisualStyleBackColor = True
        '
        'cbxTrans
        '
        Me.cbxTrans.AutoSize = True
        Me.cbxTrans.Location = New System.Drawing.Point(410, 219)
        Me.cbxTrans.Name = "cbxTrans"
        Me.cbxTrans.Size = New System.Drawing.Size(86, 17)
        Me.cbxTrans.TabIndex = 15
        Me.cbxTrans.Text = "Transgender"
        Me.cbxTrans.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(823, 23)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 19
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(823, 113)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 18
        Me.btnClear.Text = "Clear All"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(823, 296)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 23)
        Me.btnUpdate.TabIndex = 17
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(823, 200)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 16
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'Employee_Details
        '
        Me.Employee_Details.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.clmId, Me.clmName, Me.clmDob, Me.clmGender, Me.clmDepartment, Me.clmDesignation, Me.clmSalary})
        Me.Employee_Details.FullRowSelect = True
        Me.Employee_Details.GridLines = True
        Me.Employee_Details.Location = New System.Drawing.Point(80, 405)
        Me.Employee_Details.Name = "Employee_Details"
        Me.Employee_Details.Size = New System.Drawing.Size(624, 256)
        Me.Employee_Details.TabIndex = 0
        Me.Employee_Details.UseCompatibleStateImageBehavior = False
        Me.Employee_Details.View = System.Windows.Forms.View.Details
        '
        'clmId
        '
        Me.clmId.Text = "Emp_ID"
        '
        'clmName
        '
        Me.clmName.Text = "Name"
        '
        'clmDob
        '
        Me.clmDob.Text = "DOB"
        '
        'clmGender
        '
        Me.clmGender.Text = "Gender"
        '
        'clmDepartment
        '
        Me.clmDepartment.Text = "Department"
        '
        'clmDesignation
        '
        Me.clmDesignation.Text = "Designation"
        '
        'clmSalary
        '
        Me.clmSalary.Text = "Salary"
        '
        'DataGridView
        '
        Me.DataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView.Location = New System.Drawing.Point(46, 109)
        Me.DataGridView.Margin = New System.Windows.Forms.Padding(2)
        Me.DataGridView.Name = "DataGridView"
        Me.DataGridView.RowTemplate.Height = 24
        Me.DataGridView.Size = New System.Drawing.Size(16, 14)
        Me.DataGridView.TabIndex = 20
        Me.DataGridView.Visible = False
        '
        'cmb1
        '
        Me.cmb1.FormattingEnabled = True
        Me.cmb1.Location = New System.Drawing.Point(12, 64)
        Me.cmb1.Name = "cmb1"
        Me.cmb1.Size = New System.Drawing.Size(121, 21)
        Me.cmb1.TabIndex = 21
        Me.cmb1.Visible = False
        '
        'dtp1
        '
        Me.dtp1.Location = New System.Drawing.Point(245, 167)
        Me.dtp1.Name = "dtp1"
        Me.dtp1.Size = New System.Drawing.Size(200, 20)
        Me.dtp1.TabIndex = 22
        '
        'frmEmployeeDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1178, 670)
        Me.Controls.Add(Me.dtp1)
        Me.Controls.Add(Me.cmb1)
        Me.Controls.Add(Me.DataGridView)
        Me.Controls.Add(Me.lblSalary)
        Me.Controls.Add(Me.mSalary)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Employee_Details)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.EmpID)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.lblEmpId)
        Me.Controls.Add(Me.cbxTrans)
        Me.Controls.Add(Me.lblDesignation)
        Me.Controls.Add(Me.cmbDesignation)
        Me.Controls.Add(Me.Empname)
        Me.Controls.Add(Me.lblDepartment)
        Me.Controls.Add(Me.CmbDepartment)
        Me.Controls.Add(Me.cbxFemale)
        Me.Controls.Add(Me.lblEmpName)
        Me.Controls.Add(Me.DOB)
        Me.Controls.Add(Me.lblDob)
        Me.Controls.Add(Me.lblGender)
        Me.Controls.Add(Me.cbxMale)
        Me.Name = "frmEmployeeDetails"
        Me.Text = "Employee Details"
        CType(Me.DataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblEmpId As System.Windows.Forms.Label
    Friend WithEvents lblEmpName As System.Windows.Forms.Label
    Friend WithEvents lblDob As System.Windows.Forms.Label
    Friend WithEvents lblGender As System.Windows.Forms.Label
    Friend WithEvents lblDepartment As System.Windows.Forms.Label
    Friend WithEvents lblDesignation As System.Windows.Forms.Label
    Friend WithEvents lblSalary As System.Windows.Forms.Label
    Friend WithEvents EmpID As System.Windows.Forms.TextBox
    Friend WithEvents Empname As System.Windows.Forms.TextBox
    Friend WithEvents DOB As System.Windows.Forms.MaskedTextBox
    Friend WithEvents cbxMale As System.Windows.Forms.CheckBox
    Friend WithEvents CmbDepartment As System.Windows.Forms.ComboBox
    Friend WithEvents cmbDesignation As System.Windows.Forms.ComboBox
    Friend WithEvents mSalary As System.Windows.Forms.MaskedTextBox
    Friend WithEvents cbxFemale As System.Windows.Forms.CheckBox
    Friend WithEvents cbxTrans As System.Windows.Forms.CheckBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents Employee_Details As System.Windows.Forms.ListView
    Friend WithEvents clmId As System.Windows.Forms.ColumnHeader
    Friend WithEvents clmName As System.Windows.Forms.ColumnHeader
    Friend WithEvents clmDob As System.Windows.Forms.ColumnHeader
    Friend WithEvents clmGender As System.Windows.Forms.ColumnHeader
    Friend WithEvents clmDepartment As System.Windows.Forms.ColumnHeader
    Friend WithEvents clmDesignation As System.Windows.Forms.ColumnHeader
    Friend WithEvents clmSalary As System.Windows.Forms.ColumnHeader
    Friend WithEvents DataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents cmb1 As System.Windows.Forms.ComboBox
    Friend WithEvents dtp1 As System.Windows.Forms.DateTimePicker

End Class
