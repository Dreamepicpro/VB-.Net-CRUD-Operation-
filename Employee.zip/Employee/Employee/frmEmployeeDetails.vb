﻿Imports System.Configuration.ConfigurationManager
Imports MySql.Data.MySqlClient
Public Class frmEmployeeDetails

   

    Private Sub frmEmployeeDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' m_sCONN_STRING = AppSettings.Get("database_server")


        ProjectInitialize()
        MySQLConnectionOpen()

        'Department()
        Gender()

        Dim field As field_lookup
        field.initialize()
        Dim arylstDepartment As New ArrayList()
        arylstDepartment = GetFieldLookupData("Department")
        Dim i As Integer
        For i = 0 To arylstDepartment.Count - 1
            field = arylstDepartment(i)
            ' If field.slist.ToString() <> "" Then
            CmbDepartment.Items.Add(field.slist)
            ' End If
        Next



        'Dim arylstDepartment As New ArrayList()
        'arylstDepartment = GetFieldLookupData("Department")
        'Dim i As Integer
        'For i = 0 To arylstDepartment.Count - 1
        '    CmbDepartment.Items.Add(arylstDepartment(i).ToString())
        'Next

        ''Dim arylstDesignation As New ArrayList()
        ''arylstDesignation = GetFieldLookupData("Designation")
        ''Dim ides As Integer
        ''For ides = 0 To arylstDepartment.Count - 1
        ''    cmbDesignation.Items.Add(arylstDesignation(i).ToString())
        ''Next

        EmployeeList()
    End Sub
    Private Sub EmployeeList()
        Dim arrlstStudentList As New ArrayList
        Dim oStudentRecord As EmployeeDetails
        Dim oItmListItem As ListViewItem
        Dim sList As String
        Employee_Details.Items.Clear()

        arrlstStudentList = GetEmployeeDetailsTable()

        If arrlstStudentList.Count > 0 Then
            For iCount = 0 To arrlstStudentList.Count - 1
                oStudentRecord = arrlstStudentList(iCount)
                oItmListItem = New ListViewItem()

                sList = oStudentRecord.sname
                oItmListItem.Text = sList
                oItmListItem.SubItems.Add(sList)

                sList = oStudentRecord.dtDob
                oItmListItem.Text = sList
                oItmListItem.SubItems.Add(sList)
                ''''''''''''''''''''''''''''''
                sList = oStudentRecord.sgender
                oItmListItem.Text = sList
                oItmListItem.SubItems.Add(sList)
                ''''''''''''''''''''''''''''''''''
                sList = oStudentRecord.sdescription
                oItmListItem.Text = sList
                oItmListItem.SubItems.Add(sList)
                ''''''''''''''''''''''''''''''''
                sList = oStudentRecord.sdesignation
                oItmListItem.Text = sList
                oItmListItem.SubItems.Add(sList)
                ''''''''''''''''''''''''''''''''''''''
                sList = oStudentRecord.desalary
                oItmListItem.Text = sList
                oItmListItem.SubItems.Add(sList)

                sList = oStudentRecord.empid
                oItmListItem.Text = sList
                oItmListItem.SubItems.Add(sList)

                Employee_Details.Items.Add(oItmListItem)
            Next
        End If

        If Employee_Details.Items.Count = 0 Then
            MessageBox.Show("No documents are added")
        Else
            Employee_Details.Items(0).Selected = True
            Employee_Details.SelectedItems(0).Selected = True
            'lstvwStudent.Items(0).BackColor = Color.Violet
        End If

    End Sub
    

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If Empname.Text = "" Then
            MessageBox.Show("Enter Employee Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Empname.Focus()
            Exit Sub
        End If


        'If Len(DOB.Text) = 0 Then
        '    Exit Sub
        'ElseIf Len(DOB.Text) < 10 Then
        '    MessageBox.Show("Verify the Date", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    DOB.Focus()
        '    Exit Sub
        'ElseIf IsDate(DOB.Text) = False Or DOB.Text(2) <> "/" Or DOB.Text(5) <> "/" Then
        '    MessageBox.Show("Date Format is wrong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    DOB.Focus()
        '    Exit Sub
        'ElseIf DateTime.Parse(DOB.Text) > Now.Date Or DateTime.Parse(DOB.Text) < DateTime.Parse("01/01/1900") Then
        '    MessageBox.Show("Enter correct Date Format", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    Exit Sub
        'End If

        If CmbDepartment.Text = "" Then
            MessageBox.Show("Select Department", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            CmbDepartment.Focus()
            Exit Sub
        End If


        If cmbDesignation.Text = "" Then
            MessageBox.Show("Select Designation", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            cmbDesignation.Focus()
            Exit Sub
        End If

        If mSalary.Text = "" Then
            MessageBox.Show("Enter Salary", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            mSalary.Focus()
            Exit Sub
        End If
        Dim Emprecord1 As EmployeeDetails
        Emprecord1.initialize()
        If btnAdd.Text = "Add" Then
            Emprecord1.sname = Empname.Text
            Emprecord1.dtDob = dtp1.Text

            Emprecord1.sdescription = CmbDepartment.Text
            Emprecord1.sdesignation = cmbDesignation.Text
            Emprecord1.desalary = mSalary.Text
            'If cbxMale.CheckState Then
            '    Emprecord1.sgender = cbxMale.Text

            'ElseIf cbxFemale.CheckState Then
            '    Emprecord1.sgender = cbxFemale.Text

            'ElseIf cbxTrans.CheckState Then
            '    Emprecord1.sgender = cbxTrans.Text

            'End If
            Emprecord1.sgender = cmb1.Text

            Dim bReturn As Boolean = False
            bReturn = modDBOperations.AddtoEmployee(Emprecord1)
            If (bReturn = True) Then
                MessageBox.Show("Details are added successfully")
                EmployeeList()
                Exit Sub
            End If
        End If

    End Sub






    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If Empname.Text = "" Then
            MessageBox.Show("Enter Employee Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Empname.Focus()
            Exit Sub
        End If


        'If Len(DOB.Text) = 0 Then
        '    Exit Sub
        'ElseIf Len(DOB.Text) < 10 Then
        '    MessageBox.Show("Verify the Date", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    DOB.Focus()
        '    Exit Sub
        'ElseIf IsDate(DOB.Text) = False Or DOB.Text(2) <> "/" Or DOB.Text(5) <> "/" Then
        '    MessageBox.Show("Date Format is wrong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    DOB.Focus()
        '    Exit Sub
        'ElseIf DateTime.Parse(DOB.Text) > Now.Date Or DateTime.Parse(DOB.Text) < DateTime.Parse("01/01/1900") Then
        '    MessageBox.Show("Enter correct Date Format", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    Exit Sub
        'End If

        If CmbDepartment.Text = "" Then
            MessageBox.Show("Select Department", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            CmbDepartment.Focus()
            Exit Sub
        End If


        If cmbDesignation.Text = "" Then
            MessageBox.Show("Select Designation", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            cmbDesignation.Focus()
            Exit Sub
        End If

        If mSalary.Text = "" Then
            MessageBox.Show("Enter Salary", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            mSalary.Focus()
            Exit Sub
        End If

        Dim EmployeeRecord As EmployeeDetails
        EmployeeRecord.initialize()
        If btnUpdate.Text = "Update" Then
            EmployeeRecord.empid = EmpID.Text
            EmployeeRecord.sname = Empname.Text
            EmployeeRecord.dtDob = dtp1.Text

            EmployeeRecord.sdescription = CmbDepartment.Text
            EmployeeRecord.sdesignation = cmbDesignation.Text
            'If cbxMale.CheckState = True Then
            '    EmployeeRecord.sgender = cbxMale.Text

            'ElseIf cbxFemale.CheckState = True Then
            '    EmployeeRecord.sgender = cbxFemale.Text
            'ElseIf cbxTrans.CheckState = True Then
            '    EmployeeRecord.sgender = cbxTrans.Text
            'End If
            EmployeeRecord.sgender = cmb1.Text
            EmployeeRecord.desalary = mSalary.Text

            Dim bReturn As Boolean = False
            bReturn = modDBOperations.updatetoEmployeeTable(EmployeeRecord)
            If (bReturn = True) Then
                MessageBox.Show("Details are Updates successfully")
                EmployeeList()
                Exit Sub
            End If
        End If


    End Sub



    Private Sub Employee_Details_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles Employee_Details.SelectedIndexChanged
        Try
            Dim selectedIndex As Int32 = Employee_Details.SelectedIndices(0)

            If Not selectedIndex = -1 Then

                If Employee_Details.SelectedItems(0).SubItems(0).Text IsNot Nothing Then

                    EmpID.Text = Employee_Details.SelectedItems(0).SubItems(0).Text
                    Empname.Text = Employee_Details.SelectedItems(0).SubItems(1).Text
                    dtp1.Text = Employee_Details.SelectedItems(0).SubItems(2).Text
                    If Employee_Details.SelectedItems(0).SubItems(3).Text = "M" Then
                        cbxMale.Checked = True
                        cbxFemale.Checked = False
                        cbxTrans.Checked = False
                    End If
                    If Employee_Details.SelectedItems(0).SubItems(3).Text = "F" Then
                        cbxFemale.Checked = True
                        cbxTrans.Checked = False
                        cbxMale.Checked = False
                    End If
                    If Employee_Details.SelectedItems(0).SubItems(3).Text = "T" Then
                        cbxTrans.Checked = True
                        cbxMale.Checked = False
                        cbxFemale.Checked = False
                    End If
                    cmb1.Text = Employee_Details.SelectedItems(0).SubItems(3).Text
                   

                    CmbDepartment.Text = Employee_Details.SelectedItems(0).SubItems(4).Text
                    cmbDesignation.Text = Employee_Details.SelectedItems(0).SubItems(5).Text
                    mSalary.Text = Employee_Details.SelectedItems(0).SubItems(6).Text



                End If
                End If

        Catch ex As ArgumentOutOfRangeException

        End Try
        
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        clear()



    End Sub
    Sub clear()
        EmpID.Text = ""
        Empname.Text = ""
        dtp1.Text = ""
        cmb1.Text = ""
        CmbDepartment.Text = ""

        cmbDesignation.Text = ""
        mSalary.Text = ""
    End Sub
    

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub DataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView.CellContentClick

    End Sub

    Private Sub cmbDesignation_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbDesignation.SelectedIndexChanged
        cmbDesignation.Text = "Select Designation"
    End Sub

    Private Sub CmbDepartment_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbDepartment.SelectedIndexChanged
        Dim field As field_lookup
        field.initialize()
        Dim arraydesignation As New ArrayList
        If CmbDepartment.SelectedIndex = 1 Then
            cmbDesignation.Items.Clear()
            arraydesignation = GetDesignationDet("HR")
            Dim ides As Integer
            For ides = 0 To arraydesignation.Count - 1
                field = arraydesignation(ides)
                cmbDesignation.Items.Add(field.sdescription)
            Next
        End If
        If CmbDepartment.SelectedIndex = 2 Then
            cmbDesignation.Items.Clear()
            arraydesignation = GetDesignationDet("Production")
            Dim ides As Integer
            For ides = 0 To arraydesignation.Count - 1
                field = arraydesignation(ides)
                cmbDesignation.Items.Add(field.sdescription)
            Next
        End If
        If CmbDepartment.SelectedIndex = 3 Then
            cmbDesignation.Items.Clear()
            arraydesignation = GetDesignationDet("Software")
            Dim ides As Integer
            For ides = 0 To arraydesignation.Count - 1
                field = arraydesignation(ides)
                cmbDesignation.Items.Add(field.sdescription)
            Next

        End If
        'CmbDepartment.Text = "Select Department"


        'Dim sda As MySqlDataAdapter = New MySqlDataAdapter("SELECT Description FROM employee.field_lookup WHERE Category = 'Designation' AND List_Value='" & CmbDepartment.Text & "' ORDER BY Sort_Oder", oConn)

        'Dim dt As DataTable = New DataTable
        'sda.Fill(dt)
        ''Dim row As DataRow = dt.NewRow


        ''dt.Rows.InsertAt(row, 0)
        'cmbDesignation.DataSource = dt
        'cmbDesignation.DisplayMember = "Description"
        'cmbDesignation.ValueMember = ""






    End Sub
    'Sub Department()
    '    Dim sda As MySqlDataAdapter = New MySqlDataAdapter("SELECT  List_Value   FROM employee.field_lookup WHERE Category = 'Department' ORDER BY Sort_Oder", oConn)
    '    Dim dt As DataTable = New DataTable
    '    sda.Fill(dt)
    '    'Dim row As DataRow = dt.NewRow


    '    'dt.Rows.InsertAt(row, 0)
    '    CmbDepartment.DataSource = dt
    '    CmbDepartment.DisplayMember = "List_Value"
    '    CmbDepartment.ValueMember = ""




    'End Sub
    Sub Gender()
        Dim sda As MySqlDataAdapter = New MySqlDataAdapter("SELECT  Description   FROM employee.field_lookup WHERE Category = 'Gender' ORDER BY Sort_Oder", oConn)
        Dim dt As DataTable = New DataTable
        sda.Fill(dt)
        ' Dim row As DataRow ' = dt.NewRow


        'dt.Rows.InsertAt(row, 0)
        cmb1.DataSource = dt
        cmb1.DisplayMember = "Description"
        cmb1.ValueMember = ""
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub cbxMale_CheckedChanged(sender As Object, e As EventArgs) Handles cbxMale.CheckedChanged
        If cbxMale.Checked Then
            cbxFemale.Checked = False
            cbxTrans.Checked = False
        End If
    End Sub

    Private Sub cbxFemale_CheckedChanged(sender As Object, e As EventArgs) Handles cbxFemale.CheckedChanged
        If cbxFemale.Checked Then
            cbxMale.Checked = False
            cbxTrans.Checked = False
        End If
    End Sub

    Private Sub cbxTrans_CheckedChanged(sender As Object, e As EventArgs) Handles cbxTrans.CheckedChanged
        If cbxTrans.Checked Then
            cbxFemale.Checked = False
            cbxMale.Checked = False
        End If
    End Sub



End Class
